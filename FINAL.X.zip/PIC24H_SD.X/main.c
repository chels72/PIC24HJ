//******************************************************************************
//                                                                            *
//                START OF CODE
// BULT BY UCF 2020-2022 Team members include
// Chelsea Kincaid     - Clutch late game programming
// Nick Sally          - Resident Electrical Engineer
// Abbey Havel         - Optics
// Giovanni Wancelotti - Early programming
// Zach Rogers         - Thermal        
// Andrew Derusha      - 1337 3d printed components      
// Hamil Patel         - 3d printed structures
// Anthony Terracciano - The Master
// Tech lead
// PI: Subith S. Vasu        
//                                                                            
//******************************************************************************




//******************************************************************************
//       SSSSSSS    YY      YY      SSSSSSS
//      SSS          YY    YY      SSS    
//      SS            YY  YY       SS              
//       SSSSSS        YYYY         SSSSSS        
//            SS        YY               SS        
//           SSS        YY              SSS        
//      SSSSSSS         YY         SSSSSSS        
//******************************************************************************

// 7/18/2022 start address = 0x0, end address = 0xa8ff

   /*
     * On start up: 
     * system and some peripheral init, writes header file in csv format, closes file.
     * AD9833Start() starts AD9833 at "1V 1Mhz sin wave".
     * 
     * Main Loop: 
     * getC0nPOW() ADC begins sampling ch1 and ch2 with LEDA at 4Hz, number of samples based on defined NUMSAMPLES, p controls 4Hz, saves actual digital voltage to *C0 and *pow
     * getC02nPOW2() Then ADC repeats but with LEDB at 4Hz, samples based on NUMSAMPLES2,  saves actual digital voltage to *C02 and *pow2
     * Get temperature and pressure, time and date. Save all data to file in CSV format, close file.
     *
     * ADC1 is AN0, output from Photodiode for CO and CO2 intensities. LEDa is B6, LEDb is B7
     * ADC2 is AN1, output from LED Driver for power tracking
     * Data is saved to file loop.txt 
     * Date, Time, Temperature, Pressure, and ADC channels
     */

#define FOSC (20000000ULL) //sets internal clock
#define FCY (FOSC/2)

#define NUMSAMPLES 1001//sets number of samples for CO ADC, fix p in the loop if more than 1001
#define NUMSAMPLES2 1001 //for CO2 ADC

#include <stdio.h> //main headers for syntax, compiler
#include <stdlib.h>
#include <stdbool.h>
#include <xc.h>
#include <libpic30.h>
#include <string.h> 

#include "mcc_generated_files/system.h"  //for sys init, bmp280, rtc
#include "mcc_generated_files/fatfs/ff.h" //for sd formatting
#include "mcc_generated_files/sd_spi/sd_spi.h" //sd 
#include "mcc_generated_files/spi1_driver.h" //spi1 for sd
#include "mcc_generated_files/spi1_types.h" //spi1 for sd
#include "mcc_generated_files/sd_spi/../spi2_driver.h" //spi2 for ad9833
#include "mcc_generated_files/sd_spi/../spi2_types.h" //spi2 for ad9833
#include "bmp280.h" //temp press sensor
#include "DS3231.h" //rtc

//led driver clocks
void LEDA_clock(void); //pin b6, turns on and off, 4Hz, cycle is set by internal loop
void LEDB_clock(void); //pin b7, 4Hz
void AD9833Start(void); //ad9833 registers, initializes
void AD9833stop(void); //turns off, puts ad9833 into reset mode

//adc
void configADC(void); //sets registers, AN0 and AN1 pins, individual manual sampling, 10 bit
void getC0nPOW(void); //samples adc ch1 and 2 for LEDA B6, calculates average, outputs *C0 and *pow1
void getC02nPOW2(void); //samples adc ch1 and 2 for LEDB B7, calculates average, outputs *C02 and *pow2
int p; //in getC0nPOW and 2, counter for led 4Hz clock while adc is sampling
double adcc0;//what is read off the pin
double adcpow;
double adcc02;
double adcpow2;
double sumc0; //the sum of all adc pin read
double sumpow;
double sumc02;
double sumpow2;
double Dc0; //digital read of sum
double Dpow;
double Dc02;
double Dpow2;
double *C0; //average digital value in voltages, saved in SD
double *C02;
double *pow1;
double *pow2;

//temperature and pressure
double  getTemp (void); //uses bmp280, saves to variable temp
double  getPress (void); //uses bmp280, saves to variable press
double temp; //stores temp value in C
double press; //stores pressure value in mTorr 

 //sd file saving  
void fileSetup(void); //mount and opens file, code stops if fail
void fileClose(void); //unmount and close, code stops if fail
void writeFile (double **C0, double **C02, double **pow1, double **pow2, double temp, double press); //write data in csv format, gets time and date, code stops if fail
void writeHeader(void); //header for data, in csv format
FATFS fs;           /* Filesystem object */
FIL fil;            /* File object */
FRESULT res;        // API result code, for debugging
char adc[32]; //need for saving file
char str[32]; //for data saving

//*****************************************************************************
//        MM	     MM  	  AAAA       IIIIII  NN	   NN                     *         
//        MMMM	   MMMM      AA  AA		   II    NNNN  NN                     *        
//        MM MM   MM MM     AA    AA       II    NN NN NN                     *        
//        MM  MM MM  MM    AAAAAAAAAA      II    NN  NNNN                     *        
//        MM   MMM   MM   AA		AA	   II    NN   NNN                     *        
//        MM         MM  AA		     AA  IIIIII  NN	   NN                     *    
//*****************************************************************************



int main(void)
{
    /*
     * On start up: 
     * system and some peripheral init, writes header file in csv format, closes file.
     * AD9833Start() starts AD9833 at "1V 1Mhz sin wave".
     * 
     * Main Loop: 
     * getC0nPOW() ADC begins sampling ch1 and ch2 with LEDA at 4Hz, number of samples based on defined NUMSAMPLES, p controls 4Hz, saves actual digital voltage to *C0 and *pow
     * getC02nPOW2() Then ADC repeats but with LEDB at 4Hz, samples based on NUMSAMPLES2,  saves actual digital voltage to *C02 and *pow2
     * Get temperature and pressure, time and date. Save all data to file in CSV format, close file.
     *
     * ADC1 is AN0, output from Photodiode for CO and CO2 intensities. LEDa is B6, LEDb is B7
     * ADC2 is AN1, output from LED Driver for power tracking
     * Data is saved to file loop.txt 
     * Date, Time, Temperature, Pressure, and ADC channels
     */

//general configuration only ran at beginning
SYSTEM_Initialize();   
configADC(); //adc registers   


//set up csv header, lets you know when microcontroller is restarted
fileSetup();
writeHeader();
fileClose();

AD9833Start(); //begin 1Mhz signal for LED Driver
__delay_ms(1); //takes 7 clock cycles for ad9833 to output correctly

while(1) //infinite loop
{

adcc0=0; adcpow=0; adcc02=0; adcpow2=0; sumc0=0; sumpow=0; sumc02=0; sumpow2=0; Dc0=0; Dpow=0; Dc02=0; Dpow2 =0; //make sure adc math variables are 0
*C0 =0;*C02=0; *pow1=0; *pow2=0; //make sure adc data variables are 0

//get 4 ADC data values
getC0nPOW(); //adc ch1 and ch2, led a, saves the 2 averages to *C0 and *pow1
getC02nPOW2(); //led b, *C02 and *pow2

//get environmental data
getTemp(); //bmp280, saves in temp
getPress(); //bmp280, saves in press

//save data
fileSetup(); //mount and append/open file
writeFile (&C0, &C02, &pow1, &pow2, temp, press); //saves all those variables to file, gets time and date
fileClose(); //closes and unmounts sd 

}//end of main while loop 

AD9833stop(); //put ad9833 into reset mode, stop outputting

return 0;

}//end of main


//*****************************************************************************
//		 CCCCCC		  AAAA        NN	NN          FFFFFF    NN    NN        *
//		CCCCC        AA	 AA		  NNNN	NN          FF		  NNNN  NN        *
//		CC	        AA 	  AA      NN NN NN          FFFF	  NN NN NN        *
//	 	CC	   	   AAAAAAAAAA     NN  NNNN          FF		  NN  NNNN        *
//		CCCCC  	  AA		AA	  NN   NNN          FF		  NN   NNN        *
//		 CCCCCC  AA			 AA   NN	NN          FF		  NN	NN        *
//*****************************************************************************





void getC0nPOW(void)
{
    //turns on ADC1 for CO then ADC2 for power on the LEDA. Saves and averages. Also output 4Hz LEDA clock 

    
//loop for multiple adc samples on ch1 and ch2
int y;
for (y=0; y<NUMSAMPLES; y++)
{
   p=0;
  p++; //increases for LED clock 4Hz

  if (p == 1)  
  {
        LATBbits.LATB6 = 0;
        
         //AN0 on
        _ADON=0;
        _CH0SA = 0; //NEED FOR THE ADC CHANNEL 
        _ADON = 1; // turn ADC On
        __delay_us(16); //wait for adc to reset
        _SAMP=1; //start sampling
        __delay_us(10); // wait for sampling time
        AD1CON1bits.SAMP = 0; // start Converting
        while (!AD1CON1bits.DONE); //check if ready
        {
          adcc0 = ADC1BUF0; // yes then get ADC value
          AD1CON1bits.DONE = 0; //CLEAR FLAG
        }
        
        sumc0 += adcc0; //save to get average in main

        //AN1 on
        _ADON=0;
        _CH0SA = 1; //NEED FOR THE ADC CHANNEL 
        _ADON = 1; // turn ADC ON 
         __delay_us(16); //wait for adc to reset
        _SAMP=1; //start sampling
        __delay_us(10); // wait for sampling time
        AD1CON1bits.SAMP = 0; // start Converting
        while (!AD1CON1bits.DONE); //check if ready
        {
          adcpow = ADC1BUF0; // yes then get ADC value
          AD1CON1bits.DONE = 0; //CLEAR FLAG
        }

          sumpow += adcpow;  //save to get average in main
  }
  
 else if (p == 125)  
  {
        LATBbits.LATB6 = 1;
        
         //AN0 on
        _ADON=0;
        _CH0SA = 0; //NEED FOR THE ADC CHANNEL 
        _ADON = 1; // turn ADC On
         __delay_us(16); //wait for adc to reset
        _SAMP=1; //start sampling
       __delay_us(10); // wait for sampling time
        AD1CON1bits.SAMP = 0; // start Converting
        while (!AD1CON1bits.DONE); //check if ready
        {
          adcc0 = ADC1BUF0; // yes then get ADC value
          AD1CON1bits.DONE = 0; //CLEAR FLAG
        }
        
        sumc0 += adcc0; //save to get average in main

        //AN1 on
        _ADON=0;
        _CH0SA = 1; //NEED FOR THE ADC CHANNEL 
        _ADON = 1; // turn ADC ON 
         __delay_us(16); //wait for adc to reset
        _SAMP=1; //start sampling
        __delay_us(10); // wait for sampling time
        AD1CON1bits.SAMP = 0; // start Converting
        while (!AD1CON1bits.DONE); //check if ready
        {
          adcpow = ADC1BUF0; // yes then get ADC value
          AD1CON1bits.DONE = 0; //CLEAR FLAG
        }

          sumpow += adcpow;  //save to get average in main
  }
    
 else if (p == 250)  
  {
        LATBbits.LATB6 = 0;
         //AN0 on
        _ADON=0;
        _CH0SA = 0; //NEED FOR THE ADC CHANNEL 
        _ADON = 1; // turn ADC On
         __delay_us(16); //wait for adc to reset
        _SAMP=1; //start sampling
       __delay_us(10); // wait for sampling time
        AD1CON1bits.SAMP = 0; // start Converting
        while (!AD1CON1bits.DONE); //check if ready
        {
          adcc0 = ADC1BUF0; // yes then get ADC value
          AD1CON1bits.DONE = 0; //CLEAR FLAG
        }
        
        sumc0 += adcc0; //save to get average in main

        //AN1 on
        _ADON=0;
        _CH0SA = 1; //NEED FOR THE ADC CHANNEL 
        _ADON = 1; // turn ADC ON 
         __delay_us(16); //wait for adc to reset
        _SAMP=1; //start sampling
       __delay_us(10); // wait for sampling time
        AD1CON1bits.SAMP = 0; // start Converting
        while (!AD1CON1bits.DONE); //check if ready
        {
          adcpow = ADC1BUF0; // yes then get ADC value
          AD1CON1bits.DONE = 0; //CLEAR FLAG
        }

          sumpow += adcpow;  //save to get average in main
  }
    
else if (p ==500)
  {  
        LATBbits.LATB6 = 1;
         //AN0 on
        _ADON=0;
        _CH0SA = 0; //NEED FOR THE ADC CHANNEL 
        _ADON = 1; // turn ADC On
         __delay_us(16); //wait for adc to reset
        _SAMP=1; //start sampling
       __delay_us(10); // wait for sampling time
        AD1CON1bits.SAMP = 0; // start Converting
        while (!AD1CON1bits.DONE); //check if ready
        {
          adcc0 = ADC1BUF0; // yes then get ADC value
          AD1CON1bits.DONE = 0; //CLEAR FLAG
        }
        
        sumc0 += adcc0; //save to get average in main

        //AN1 on
        _ADON=0;
        _CH0SA = 1; //NEED FOR THE ADC CHANNEL 
        _ADON = 1; // turn ADC ON 
         __delay_us(16); //wait for adc to reset
        _SAMP=1; //start sampling
        __delay_us(10); // wait for sampling time
        AD1CON1bits.SAMP = 0; // start Converting
        while (!AD1CON1bits.DONE); //check if ready
        {
          adcpow = ADC1BUF0; // yes then get ADC value
          AD1CON1bits.DONE = 0; //CLEAR FLAG
        }

          sumpow += adcpow;  //save to get average in main
   }
    
 else if (p == 750)  
   {
        LATBbits.LATB6 = 0;
         //AN0 on
        _ADON=0;
        _CH0SA = 0; //NEED FOR THE ADC CHANNEL 
        _ADON = 1; // turn ADC On
         __delay_us(16); //wait for adc to reset
        _SAMP=1; //start sampling
        __delay_us(10); // wait for sampling time
        AD1CON1bits.SAMP = 0; // start Converting
        while (!AD1CON1bits.DONE); //check if ready
        {
          adcc0 = ADC1BUF0; // yes then get ADC value
          AD1CON1bits.DONE = 0; //CLEAR FLAG
        }
        
        sumc0 += adcc0; //save to get average in main

        //AN1 on
        _ADON=0;
        _CH0SA = 1; //NEED FOR THE ADC CHANNEL 
        _ADON = 1; // turn ADC ON 
         __delay_us(16); //wait for adc to reset
        _SAMP=1; //start sampling
       __delay_us(10); // wait for sampling time
        AD1CON1bits.SAMP = 0; // start Converting
        while (!AD1CON1bits.DONE); //check if ready
        {
          adcpow = ADC1BUF0; // yes then get ADC value
          AD1CON1bits.DONE = 0; //CLEAR FLAG
        }

          sumpow += adcpow;  //save to get average in main
   }
    
 else   if (p == 999)  
   {
       LATBbits.LATB6 = 1;
         //AN0 on
        _ADON=0;
        _CH0SA = 0; //NEED FOR THE ADC CHANNEL 
        _ADON = 1; // turn ADC On
         __delay_us(16); //wait for adc to reset
        _SAMP=1; //start sampling
       __delay_us(10); // wait for sampling time
        AD1CON1bits.SAMP = 0; // start Converting
        while (!AD1CON1bits.DONE); //check if ready
        {
          adcc0 = ADC1BUF0; // yes then get ADC value
          AD1CON1bits.DONE = 0; //CLEAR FLAG
        }
        
        sumc0 += adcc0; //save to get average in main

        //AN1 on
        _ADON=0;
        _CH0SA = 1; //NEED FOR THE ADC CHANNEL 
        _ADON = 1; // turn ADC ON 
         __delay_us(16); //wait for adc to reset
        _SAMP=1; //start sampling
        __delay_us(10); // wait for sampling time
        AD1CON1bits.SAMP = 0; // start Converting
        while (!AD1CON1bits.DONE); //check if ready
        {
          adcpow = ADC1BUF0; // yes then get ADC value
          AD1CON1bits.DONE = 0; //CLEAR FLAG
        }

          sumpow += adcpow;  //save to get average in main
  } 
    
  
 else if (p==1000) //basically always do at end, for saving values
{
Dc0 = (sumc0 * 3.3) /1024;
*C0 = (Dc0/NUMSAMPLES); //pointer so fnc can return 2 values

Dpow = (sumpow *3.3) / 1024;
*pow1 = (Dpow / NUMSAMPLES);
 _LATB6=0;

}
 else
 {
     _LATB6=0;
 }
}

}



void getC02nPOW2(void)
{
     //turns on ADC1 for CO2 then ADC2 for power on the LEDB. Saves and averages. Also output 4Hz LEDB clock
    
//loop for multiple adc samples on ch1 and ch2
int y;
for (y=0; y<NUMSAMPLES2; y++)
{
  p=0; //controls LED 
  p++; //increases for LED clock 4Hz

  if (p == 1)  
  {
        LATBbits.LATB7 = 0;
        
         //AN0 on
        _ADON=0;
        _CH0SA = 0; //NEED FOR THE ADC CHANNEL 
        _ADON = 1; // turn ADC On
         __delay_us(16); //wait for adc to reset
        _SAMP=1; //start sampling
        __delay_ms(1); // sample for __ mS
        AD1CON1bits.SAMP = 0; // start Converting
        while (!AD1CON1bits.DONE); //check if ready
        {
          adcc02 = ADC1BUF0; // yes then get ADC value
          AD1CON1bits.DONE = 0; //CLEAR FLAG
        }
        
        sumc02 += adcc02; //save to get average in main

        //AN1 on
        _ADON=0;
        _CH0SA = 1; //NEED FOR THE ADC CHANNEL 
        _ADON = 1; // turn ADC ON 
         __delay_us(16); //wait for adc to reset
        _SAMP=1; //start sampling
         __delay_ms(1); // sample for __ mS
        AD1CON1bits.SAMP = 0; // start Converting
        while (!AD1CON1bits.DONE); //check if ready
        {
          adcpow2 = ADC1BUF0; // yes then get ADC value
          AD1CON1bits.DONE = 0; //CLEAR FLAG
        }

          sumpow2 += adcpow2;  //save to get average in main
  }
  
 else if (p == 125)  
  {
        LATBbits.LATB7 = 1;
        
         //AN0 on
        _ADON=0;
        _CH0SA = 0; //NEED FOR THE ADC CHANNEL 
        _ADON = 1; // turn ADC On
         __delay_us(16); //wait for adc to reset
        _SAMP=1; //start sampling
        __delay_ms(1); // sample for __ mS
        AD1CON1bits.SAMP = 0; // start Converting
        while (!AD1CON1bits.DONE); //check if ready
        {
          adcc02 = ADC1BUF0; // yes then get ADC value
          AD1CON1bits.DONE = 0; //CLEAR FLAG
        }
        
        sumc02 += adcc02; //save to get average in main

        //AN1 on
        _ADON=0;
        _CH0SA = 1; //NEED FOR THE ADC CHANNEL 
        _ADON = 1; // turn ADC ON 
         __delay_us(16); //wait for adc to reset
        _SAMP=1; //start sampling
         __delay_ms(1); // sample for __ mS
        AD1CON1bits.SAMP = 0; // start Converting
        while (!AD1CON1bits.DONE); //check if ready
        {
          adcpow2 = ADC1BUF0; // yes then get ADC value
          AD1CON1bits.DONE = 0; //CLEAR FLAG
        }

          sumpow2 += adcpow2;  //save to get average in main
  }
    
 else if (p == 250)  
  {
        LATBbits.LATB7 = 0;
        
         //AN0 on
        _ADON=0;
        _CH0SA = 0; //NEED FOR THE ADC CHANNEL 
        _ADON = 1; // turn ADC On
         __delay_us(16); //wait for adc to reset
        _SAMP=1; //start sampling
        __delay_ms(1); // sample for __ mS
        AD1CON1bits.SAMP = 0; // start Converting
        while (!AD1CON1bits.DONE); //check if ready
        {
          adcc02 = ADC1BUF0; // yes then get ADC value
          AD1CON1bits.DONE = 0; //CLEAR FLAG
        }
        
        sumc02 += adcc02; //save to get average in main

        //AN1 on
        _ADON=0;
        _CH0SA = 1; //NEED FOR THE ADC CHANNEL 
        _ADON = 1; // turn ADC ON 
         __delay_us(16); //wait for adc to reset
        _SAMP=1; //start sampling
         __delay_ms(1); // sample for __ mS
        AD1CON1bits.SAMP = 0; // start Converting
        while (!AD1CON1bits.DONE); //check if ready
        {
          adcpow2 = ADC1BUF0; // yes then get ADC value
          AD1CON1bits.DONE = 0; //CLEAR FLAG
        }

          sumpow2 += adcpow2;  //save to get average in main
  }
    
else if (p ==500)
  {  
        LATBbits.LATB7 = 1;
         
         //AN0 on
        _ADON=0;
        _CH0SA = 0; //NEED FOR THE ADC CHANNEL 
        _ADON = 1; // turn ADC On
         __delay_us(16); //wait for adc to reset
        _SAMP=1; //start sampling
        __delay_ms(1); // sample for __ mS
        AD1CON1bits.SAMP = 0; // start Converting
        while (!AD1CON1bits.DONE); //check if ready
        {
          adcc02 = ADC1BUF0; // yes then get ADC value
          AD1CON1bits.DONE = 0; //CLEAR FLAG
        }
        
        sumc02 += adcc02; //save to get average in main

        //AN1 on
        _ADON=0;
        _CH0SA = 1; //NEED FOR THE ADC CHANNEL 
        _ADON = 1; // turn ADC ON 
         __delay_us(16); //wait for adc to reset
        _SAMP=1; //start sampling
         __delay_ms(1); // sample for __ mS
        AD1CON1bits.SAMP = 0; // start Converting
        while (!AD1CON1bits.DONE); //check if ready
        {
          adcpow2 = ADC1BUF0; // yes then get ADC value
          AD1CON1bits.DONE = 0; //CLEAR FLAG
        }

          sumpow2 += adcpow2;  //save to get average in main
   }
    
 else if (p == 750)  
   {
        LATBbits.LATB7 = 0;
         
         //AN0 on
        _ADON=0;
        _CH0SA = 0; //NEED FOR THE ADC CHANNEL 
        _ADON = 1; // turn ADC On
         __delay_us(16); //wait for adc to reset
        _SAMP=1; //start sampling
        __delay_ms(1); // sample for __ mS
        AD1CON1bits.SAMP = 0; // start Converting
        while (!AD1CON1bits.DONE); //check if ready
        {
          adcc02 = ADC1BUF0; // yes then get ADC value
          AD1CON1bits.DONE = 0; //CLEAR FLAG
        }
        
        sumc02 += adcc02; //save to get average in main

        //AN1 on
        _ADON=0;
        _CH0SA = 1; //NEED FOR THE ADC CHANNEL 
        _ADON = 1; // turn ADC ON 
         __delay_us(16); //wait for adc to reset
        _SAMP=1; //start sampling
         __delay_ms(1); // sample for __ mS
        AD1CON1bits.SAMP = 0; // start Converting
        while (!AD1CON1bits.DONE); //check if ready
        {
          adcpow2 = ADC1BUF0; // yes then get ADC value
          AD1CON1bits.DONE = 0; //CLEAR FLAG
        }

          sumpow2 += adcpow2;  //save to get average in main
   }
    
 else   if (p == 999)  
   {
       LATBbits.LATB7 = 1;
        
         //AN0 on
        _ADON=0;
        _CH0SA = 0; //NEED FOR THE ADC CHANNEL 
        _ADON = 1; // turn ADC On
         __delay_us(16); //wait for adc to reset
        _SAMP=1; //start sampling
        __delay_ms(1); // sample for __ mS
        AD1CON1bits.SAMP = 0; // start Converting
        while (!AD1CON1bits.DONE); //check if ready
        {
          adcc02 = ADC1BUF0; // yes then get ADC value
          AD1CON1bits.DONE = 0; //CLEAR FLAG
        }
        
        sumc02 += adcc02; //save to get average in main

        //AN1 on
        _ADON=0;
        _CH0SA = 1; //NEED FOR THE ADC CHANNEL 
        _ADON = 1; // turn ADC ON 
         __delay_us(16); //wait for adc to reset
        _SAMP=1; //start sampling
         __delay_ms(1); // sample for __ mS
        AD1CON1bits.SAMP = 0; // start Converting
        while (!AD1CON1bits.DONE); //check if ready
        {
          adcpow2 = ADC1BUF0; // yes then get ADC value
          AD1CON1bits.DONE = 0; //CLEAR FLAG
        }

          sumpow2 += adcpow2;  //save to get average in main
   }
//end of main part of the loop
  
    
 else if (p==1000) //basically always do at end, for saving values
{
Dc02 = (sumc02 * 3.3) /1024;
*C02 = (Dc02/NUMSAMPLES2); 

Dpow2 = (sumpow2 *3.3) / 1024;
*pow2 = (Dpow2 / NUMSAMPLES2);


     _LATB7=0;
 }

 else
 {
       _LATB7=0;
 }
}
}


//gets temp
double  getTemp(void)
{
        temp = BMP280_ReadTemperature();
        return temp; //to save on sd
}

//gets press
double  getPress(void)
{
    press = BMP280_ReadPressure();  
    return press; //to save on sd
}

//header in csv format
void writeHeader(void)
{
    //date
      sprintf(adc, "Date (#:MM:DD:YY)");
        f_puts(adc, &fil);
        
        sprintf( adc, ",");
        f_puts(adc, &fil);
        sprintf(adc, "Cali Date (#:MM:DD:YY)");
        f_puts(adc, &fil);
        
        sprintf( adc, ",");
        f_puts(adc, &fil);
    //time
      sprintf(adc, "Time (HH:MM:SS)");
        f_puts(adc, &fil);
        
        sprintf( adc, ",");
        f_puts(adc, &fil); 
        
        sprintf(adc, "CaliTime (HH:MM:SS)");
        f_puts(adc, &fil);
        
        sprintf( adc, ",");
        f_puts(adc, &fil); 
     //adc ch1. led a
          sprintf(adc, "CO (V)");
        f_puts(adc, &fil);
        
        sprintf( adc, ",");
        f_puts(adc, &fil); 
        
     //adc ch1, led b
          sprintf(adc, "CO2 (V)");
        f_puts(adc, &fil);
        
        sprintf( adc, ",");
        f_puts(adc, &fil); 
      //ADC CH2  
          sprintf(adc, "LEDA PWR (V)");
        f_puts(adc, &fil);
        
        sprintf( adc, ",");
        f_puts(adc, &fil); 
        
                  sprintf(adc, "LEDB PWR (V)");
        f_puts(adc, &fil);
        
        sprintf( adc, ",");
        f_puts(adc, &fil); 
      //TEMP
          sprintf(adc, "Temp (C)");
        f_puts(adc, &fil);
        
        sprintf( adc, ",");
        f_puts(adc, &fil); 
     //PRESS   
          sprintf(adc, "Press (mTorr)\r");
        f_puts(adc, &fil);

}

//WRITE DATA
void writeFile (double **C0, double **C02, double **pow1, double **pow2, double  temp, double  press)
{

     DS3231_RefreshTime(); //set time and date
     
      Generate_Datestamp(str);
      sprintf(adc, "%s", str);
      f_puts(str, &fil);
        
      sprintf( adc, ",");
        f_puts(adc, &fil); 
     
        Calibrate_Datestamp(str); //get right date
        sprintf(adc, "%s", str);
      f_puts(str, &fil);
        
      sprintf( adc, ",");
        f_puts(adc, &fil); 

        Generate_Timestamp(str);

      sprintf(adc, "%s", str);
        f_puts(str, &fil);
        
      sprintf( adc, ",");
        f_puts(adc, &fil);
        
         Calibrate_Timestamp(str);

      sprintf(adc, "%s", str);
        f_puts(str, &fil);
        
      sprintf( adc, ",");
        f_puts(adc, &fil);
 
        sprintf(adc, "%.3f", **C0);
        f_puts(adc, &fil);
        
          sprintf(adc,",");
        f_puts(adc, &fil);
        
        sprintf(adc, "%.3f", **C02);
        f_puts(adc, &fil);
        
          sprintf(adc,",");
        f_puts(adc, &fil); 
        
               sprintf(adc, "%.3f", **pow1);
        f_puts(adc, &fil);
        
          sprintf( adc, ",");
        f_puts(adc, &fil);
        
                  sprintf(adc, "%.3f", **pow2);
        f_puts(adc, &fil);
        
          sprintf( adc, ",");
        f_puts(adc, &fil);
        
               sprintf(adc, "%.3f", temp);
        f_puts(adc, &fil);
        
          sprintf( adc, ",");
        f_puts(adc, &fil);
        
               sprintf(adc, "%.3f\r", press);
        f_puts(adc, &fil);

}

 
//mounts and opens/appends file
void fileSetup(void)
{
    //mount
    res = f_mount(&fs, "", 1);
            while(res != FR_OK)//do not continue
          {_LATB7=1; }
    //open/append
    res = f_open(&fil, "loop.txt", FA_OPEN_APPEND | FA_WRITE);
      while(res != FR_OK)//do not continue
        { _LATB6=1; }    
}

//unmounts and close
void fileClose(void)
{
    res = f_close(&fil);
        while(res != FR_OK)//do not continue
        {_LATB7=1;}
    
    res = f_mount(0,"",0); //unmount disk
        while(res != FR_OK)//do not continue
        { _LATB7=1; }
}


//4Hz led clock
void LEDA_clock(void)
{
    int x;
    for (x=0; x<5; x++)
    {
    LATBbits.LATB6 = 0;
    __delay_ms(125); //125ms makes 4Hz
    LATBbits.LATB6 = 1;
    __delay_ms(125);
    }
}

//4Hz led clock
void LEDB_clock(void){
   int y;
   for (y=0; y<5; y++)
    {
    LATBbits.LATB7 = 0;
    __delay_ms(125);
    LATBbits.LATB7 = 1;
    __delay_ms(125);
    } 
}


void AD9833Start(void)
{
 #define AD9833_SPI_ChipSelect()     (_LATB14 = 0) // CS pin for ad9833, spi2
#define AD9833_SPI_ChipDeselect()   (_LATB14 = 1)

    //binary values from ad9833 datasheet, split into 8bit arrays needed to feed spi_write
    uint8_t CONTROL= {0x21};
    uint8_t CONTROL2= {0x00};
    uint8_t FREQ0L = {0xCC}; //changed to 1Mhz
    uint8_t FREQ0L2 = {0xCC};
    uint8_t FREQ0M= {0xCC};
    uint8_t FREQ0M2 = {0xCC};
    uint8_t PHASE0 = {0xC0};
    uint8_t PHASE02 = {0x00};
    uint8_t EXIT  = {0x20};
    uint8_t EXIT2  = {0x00};
    

//chip select and deselect used according to ad9833 datasheet as 16 bits are passed except freq0
    AD9833_SPI_ChipDeselect();
  __delay_us(1);  
  AD9833_SPI_ChipSelect();

    
spi2_writeByte(CONTROL);
spi2_writeByte(CONTROL2);
    
    AD9833_SPI_ChipDeselect();
  __delay_us(1);  
  AD9833_SPI_ChipSelect();
  

spi2_writeByte(FREQ0L);  
spi2_writeByte(FREQ0L2);  

spi2_writeByte(FREQ0M);
spi2_writeByte(FREQ0M2);

    AD9833_SPI_ChipDeselect();
  __delay_us(1);  
  AD9833_SPI_ChipSelect();
  
spi2_writeByte(PHASE0);
spi2_writeByte(PHASE02);

    AD9833_SPI_ChipDeselect();
  __delay_us(1);  
  AD9833_SPI_ChipSelect();
  
spi2_writeByte(EXIT);
spi2_writeByte(EXIT2); //output 7 mclk cycles after this 

    AD9833_SPI_ChipDeselect();
  __delay_us(1);  
  AD9833_SPI_ChipSelect();
                   

}

//turns off ad9833
void AD9833stop(void)
{
    //writes to spi reset=1, no output on ad9833
    uint8_t CONTROL = {0x21};
    uint8_t CONTROL2 = {0x00};
        
spi2_writeByte(CONTROL);
spi2_writeByte(CONTROL2);

}


//ADC registers
void configADC(void){
    //sets pins
    _TRISA1 = 1; //sets pin to input AN1
    _PCFG1 = 0; //0 = Port pin in Analog mode, port read input disabled, ADC samples pin voltage
    _TRISA0 = 1; //sets pin to input AN0
    _PCFG0 = 0; //0 = Port pin in Analog mode, port read input disabled, ADC samples pin voltage
        
    //register ad1con1
    _ADON = 0; //ADC IS OFF, LEAVE THIS NOT TO MESS UP SETTING UP
    //ADSIDL FOR IDLE MODE
    _AD12B = 0 ; // SETS 12 BIT, 1 CH, 0 IS 10 BIT 4CH CHANGE SIMSAM TOO
    _FORM = 0; //POSITIVE INTEGER
    _SSRC = 0; //NEEDS TO BE 0!!!
    _ASAM = 0; // AUTOSETS SAMPLINGS
    _SIMSAM = 0; // SAMPLES CHS SIMULATANEOUSLY if 1
            
    //REGISTER AD1CON2
    _VCFG = 000; //SETS VOLT REF
    //_CSCNA SCANS CHANNELS
    _CHPS = 01; //SETS CH0 AND CH1
    //BUFS MAKE BUFFER FASTER
    _SMPI = 0;
    //_BUFM START FILLING BUFFER
    
    //REGISTER AD1CON3
    _ADRC = 1; //INTERNAL RC CLOCK
    
    //ACTIVATE AD1CHS123 WHEN USING MORE THAN 1 CH
    //register AD1CHS123
    _CH123SB = 0; //SETS AN0, AN1, AND AN2 AS POS CH
    
    _CH0NB= 0;
    _CH0SB =1;
    //REGISTER AD1CHS
    _CH0NA = 0;//NEG REF IS VREF-

    //REGISTER INTCON1
    _NSTDIS = 0 ; //DISABLE INTERRUPT OVERLAP
   
    AD1CON3bits.ADRC = 0; // ADC Clock is derived from Systems Clock
    AD1CON3bits.SAMC = 0; // Auto Sample Time = 0 * TAD
    AD1CON3bits.ADCS = 2; // ADC Conversion Clock TAD = TCY * (ADCS + 1) = (1/40M) * 3 = 75 ns (13.3 MHz)
     // ADC Conversion Time for 10-bit Tconv = 12 * TAD = 900 ns (1.1 MHz)
    AD1CON1bits.ADDMABM = 1; // DMA buffers are built in conversion order mode
    IFS0bits.AD1IF = 0; // Clear the Analog-to-Digital interrupt flag bit
    IEC0bits.AD1IE = 0; // Do Not Enable Analog-to-Digital interrupt
}

//*****************************************************************************
//					EEEEEEE 	NN    NN	DDDDDD                            *
//					EE      	NNNN  NN	DD   DD                           *
//					EEEE    	NN NN NN	DD    DD                          *
//					EEEE    	NN  NNNN	DD    DD                          *
//					EE     		NN   NNN	DD   DD                           *
//					EEEEEEE 	NN    NN	DDDDDD                            *
//*****************************************************************************