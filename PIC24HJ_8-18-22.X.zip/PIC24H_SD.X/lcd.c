/*
 * File:   lcd.c
 * Author: chelsea2
 *
 * Created on August 17, 2022, 12:25 PM
 */
//LCD screen
#include "OLED/OLED.h" //for debugging LCD screen
void OLED_Readout(char *str); 
void OLED_Readout2(char *str);
void checkSDReturn(FRESULT result);
char str [32];

#include "xc.h"
#include "OLED/OLED.h" //for debugging LCD screen
void OLED_Readout(char *str); 
void OLED_Readout2(char *str);
void checkSDReturn(FRESULT result);
char str [32];

//print string with .5 second delay
void OLED_Readout(char *str)
{
    OLED_ClearDisplay();
    OLED_Write_Text(0,0,str);
    OLED_Update();
    __delay_ms(500);
}
void OLED_Readout2(char *str)
{
    OLED_ClearDisplay();
    OLED_Write_Text(0,8,str);
    OLED_Update();
    __delay_ms(500);
}

//for debugging SD card
void checkSDReturn(FRESULT result)
{
    switch(result){
        case FR_DISK_ERR:
            OLED_Readout2("FR_DISK_ERR");
            break;
            
        case FR_INT_ERR:
            OLED_Readout2("FR_INT_ERR");
            break;
            
        case FR_NOT_READY:
            OLED_Readout2("FR_NOT_READY");
            break;
        
        case FR_NO_FILE:
            OLED_Readout2("FR_NO_FILE");
            break;
        
        case FR_NO_PATH:
            OLED_Readout2("FR_NO_PATH");
            break;
            
        case FR_INVALID_NAME:
            OLED_Readout2("FR_INVALID_NAME");
            break;
            
        case FR_DENIED:
            OLED_Readout2("FR_DENIED");
            break;
            
        case FR_EXIST:
            OLED_Readout2("FR_EXIST");
            break;
            
        case FR_INVALID_OBJECT:
            OLED_Readout2("FR_INVALID_OBJECT");
            break;
            
        case FR_WRITE_PROTECTED:
            OLED_Readout2("FR_WRITE_PROTECTED");
            break;
            
        case FR_INVALID_DRIVE:
            OLED_Readout2("FR_INVALID_DRIVE");
            break;
            
        case FR_NOT_ENABLED:
            OLED_Readout2("FR_NOT_ENABLED");
            break;
            
        case FR_NO_FILESYSTEM:
            OLED_Readout2("FR_NO_FILESYSTEM");
            break;
            
        case FR_MKFS_ABORTED:
            OLED_Readout2("FR_MKFS_ABORTED");
            break;
            
        default:
            OLED_Readout2("Dunno");
            break;
    }
}