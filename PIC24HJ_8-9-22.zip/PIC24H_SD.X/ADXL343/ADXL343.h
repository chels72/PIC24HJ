/*
    @file ADXL343.h

    This is a library adapted for the PIC24H to be used with the ADXL343

    Based off of the Adafruit ADXL343 Library

    Giovanni Wancelotti (University of Central Florida)
*/

#ifndef _ADXL343_H
#define _ADXL343_H

#include <stdbool.h>
#include <stdint.h>

//////////////////////////
/* Constant Definitions */
//////////////////////////

#define ADXL343_ADDRESS 0x53 /**< Assumes ALT address pin low */

enum{
    ADXL343_REG_DEVID = 0x00,        /**< Device ID */
    ADXL343_REG_THRESH_TAP = 0x1D,   /**< Tap threshold */
    ADXL343_REG_OFSX = 0x1E,         /**< X-axis offset */
    ADXL343_REG_OFSY = 0x1F,         /**< Y-axis offset */
    ADXL343_REG_OFSZ = 0x20,         /**< Z-axis offset */
    ADXL343_REG_DUR = 0x21,          /**< Tap duration */
    ADXL343_REG_LATENT = 0x22,       /**< Tap latency */
    ADXL343_REG_WINDOW = 0x23,       /**< Tap window */
    ADXL343_REG_THRESH_ACT = 0x24,   /**< Activity threshold */
    ADXL343_REG_THRESH_INACT = 0x25, /**< Inactivity threshold */
    ADXL343_REG_TIME_INACT = 0x26,   /**< Inactivity time */
    ADXL343_REG_ACT_INACT_CTL = 0x27, /**< Axis enable control for activity and inactivity detection */
    ADXL343_REG_THRESH_FF = 0x28, /**< Free-fall threshold */
    ADXL343_REG_TIME_FF = 0x29,   /**< Free-fall time */
    ADXL343_REG_TAP_AXES = 0x2A,  /**< Axis control for single/double tap */
    ADXL343_REG_ACT_TAP_STATUS = 0x2B, /**< Source for single/double tap */
    ADXL343_REG_BW_RATE = 0x2C,     /**< Data rate and power mode control */
    ADXL343_REG_POWER_CTL = 0x2D,   /**< Power-saving features control */
    ADXL343_REG_INT_ENABLE = 0x2E,  /**< Interrupt enable control */
    ADXL343_REG_INT_MAP = 0x2F,     /**< Interrupt mapping control */
    ADXL343_REG_INT_SOURCE = 0x30,  /**< Source of interrupts */
    ADXL343_REG_DATA_FORMAT = 0x31, /**< Data format control */
    ADXL343_REG_DATAX0 = 0x32,      /**< X-axis data 0 */
    ADXL343_REG_DATAX1 = 0x33,      /**< X-axis data 1 */
    ADXL343_REG_DATAY0 = 0x34,      /**< Y-axis data 0 */
    ADXL343_REG_DATAY1 = 0x35,      /**< Y-axis data 1 */
    ADXL343_REG_DATAZ0 = 0x36,      /**< Z-axis data 0 */
    ADXL343_REG_DATAZ1 = 0x37,      /**< Z-axis data 1 */
    ADXL343_REG_FIFO_CTL = 0x38,    /**< FIFO control */
    ADXL343_REG_FIFO_STATUS = 0x39  /**< FIFO status */
};

/** Used with register 0x2C (ADXL343_REG_BW_RATE) to set bandwidth */
typedef enum {
  ADXL343_DATARATE_3200_HZ = 0b1111, /**< 3200Hz Bandwidth */
  ADXL343_DATARATE_1600_HZ = 0b1110, /**< 1600Hz Bandwidth */
  ADXL343_DATARATE_800_HZ = 0b1101,  /**<  800Hz Bandwidth */
  ADXL343_DATARATE_400_HZ = 0b1100,  /**<  400Hz Bandwidth */
  ADXL343_DATARATE_200_HZ = 0b1011,  /**<  200Hz Bandwidth */
  ADXL343_DATARATE_100_HZ = 0b1010,  /**<  100Hz Bandwidth */
  ADXL343_DATARATE_50_HZ = 0b1001,   /**<   50Hz Bandwidth */
  ADXL343_DATARATE_25_HZ = 0b1000,   /**<   25Hz Bandwidth */
  ADXL343_DATARATE_12_5_HZ = 0b0111, /**< 12.5Hz Bandwidth */
  ADXL343_DATARATE_6_25HZ = 0b0110,  /**< 6.25Hz Bandwidth */
  ADXL343_DATARATE_3_13_HZ = 0b0101, /**< 3.13Hz Bandwidth */
  ADXL343_DATARATE_1_56_HZ = 0b0100, /**< 1.56Hz Bandwidth */
  ADXL343_DATARATE_0_78_HZ = 0b0011, /**< 0.78Hz Bandwidth */
  ADXL343_DATARATE_0_39_HZ = 0b0010, /**< 0.39Hz Bandwidth */
  ADXL343_DATARATE_0_20_HZ = 0b0001, /**< 0.20Hz Bandwidth */
  ADXL343_DATARATE_0_10_HZ = 0b0000  /**< 0.10Hz Bandwidth (default value) */
} dataRate_t;

/** Used with register 0x31 (ADXL343_REG_DATA_FORMAT) to set g range */
typedef enum {
  ADXL343_RANGE_16_G = 0b11, /**< +/- 16g */
  ADXL343_RANGE_8_G = 0b10,  /**< +/- 8g */
  ADXL343_RANGE_4_G = 0b01,  /**< +/- 4g */
  ADXL343_RANGE_2_G = 0b00   /**< +/- 2g (default value) */
} range_t;

union int_config {
  uint8_t value; /**< Composite 8-bit value of the bitfield.*/
  struct {
    uint8_t overrun : 1;    /**< Bit 0 */
    uint8_t watermark : 1;  /**< Bit 1 */
    uint8_t freefall : 1;   /**< Bit 2 */
    uint8_t inactivity : 1; /**< Bit 3 */
    uint8_t activity : 1;   /**< Bit 4 */
    uint8_t double_tap : 1; /**< Bit 5 */
    uint8_t single_tap : 1; /**< Bit 6 */
    uint8_t data_ready : 1; /**< Bit 7 */
  } bits;                   /**< Individual bits in the bitfield. */
};

///////////////////////////
/* Function Declerations */
///////////////////////////

/*
     @Summary
        Initializes the ADXL343 Sensor on I2C

    @Description
        This routine initializes the ADXL343 sensor and prepares it for use.
        User provides sampling modes based on design requirements.

    @Preconditions
        Must have initialized I2C
    
    @Param
        rate - Sampling rate of the sensor.

    @Param
        range - Range over the 16bit return represents (from +-2g to +-16g)
*/

bool ADXL343_Initialize  (dataRate_t rate, range_t range);

/*
     @Summary
        Reads magnitude of Acceleration from the ADXL343

    @Description
        This routine uses the I2C bus to read the acceleration registers and
        get the magnitude of the acceleration vector (x, y, z).

        Scale it to appropriate setting to get value in G's

    @Preconditions
        Must have called ADXL343_Initialize
    
    @Param
        None

    @Returns
        Acceleration in m/s^2
*/

float ADXL343_getAccel(void);

/*
     @Summary
        Reads magnitude of Acceleration for one direction from the ADXL343

    @Description
        This routine uses the I2C bus to read the acceleration register 
        (for either x, y, OR z).

        Return scale depends on settings (Refer to datasheet)
 * 
    @Preconditions
        Must have called ADXL343_Initialize
    
    @Param
        None

    @Returns
        signed int 16 (-32,768 to 32,767)
*/

int16_t ADXL343_getX(void);
int16_t ADXL343_getY(void);
int16_t ADXL343_getZ(void);


float ADXL343_getX_Accel(void);
float ADXL343_getY_Accel(void);
float ADXL343_getZ_Accel(void);
#endif