#ifndef AD9833_H
#define	AD9833_H

#include <stdbool.h>
#include <stdint.h>

///////////////////////////
/* Function Declarations */
///////////////////////////

bool AD9833_Initialize(void);

#endif
